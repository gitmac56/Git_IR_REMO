/*******************************************************************************
* File Name: UART1.c
* Version 1.50
*
* Description:
*  This file provides the source code to the API for the Software Transmit UART.
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "UART1_PVT.h"

#if(UART1_PIN_STATIC_MODE == 1u)
    uint32 UART1_pinNumber = UART1_PIN_NUMBER;
    uint32 UART1_pinPortNumber = UART1_PIN_PORT_NUMBER;
    #if(CY_PSOC3)
        uint32 pdata UART1_pinDrAdress = UART1_PIN_DR;
    #else
        uint32 UART1_pinDrAdress = UART1_PIN_DR;
    #endif /* (CY_PSOC3) */
#else
    uint32 UART1_pinNumber;
    uint32 UART1_pinPortNumber;
    #if(CY_PSOC3)
        uint32 pdata UART1_pinDrAdress;
    #else
        uint32 UART1_pinDrAdress;
    #endif /* (CY_PSOC3) */
#endif /* (UART1_PIN_STATIC_MODE == 1u) */


#if(UART1_PIN_STATIC_MODE == 1u)
    /*******************************************************************************
    * Function Name: UART1_Start
    ********************************************************************************
    *
    * Summary:
    *  Empty function. Included for consistency with other
    *  components. This API is not available when PinAssignmentMethod
    *  is set to Dynamic.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void UART1_Start(void) 
    {

    }
#else
    /*******************************************************************************
    * Function Name: UART1_StartEx
    ********************************************************************************
    *
    * Summary:
    *  Configures the SW Tx UART to use the pin specified
    *  by the parameters. This API is only available when
    *  PinAssignmentMethod is set to Dynamic.
    *
    * Parameters:
    *  port:  Port number for dynamic pin assignment
    *  pin:   Pin number for dynamic pin assignment
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void UART1_StartEx(uint8 port, uint8 pin) 
    {
        uint32 portConfigAddr;

        #if (CY_PSOC4)
            uint32 portDataRegAddr;
        #endif /* (CY_PSOC4) */

        if ((pin <= UART1_MAX_PIN_NUMBER) && (port <= UART1_MAX_PORT_NUMBER))
        {
            #if (!CY_PSOC4)
                portConfigAddr = UART1_PORT_CNF_BASE;
                portConfigAddr += ((uint32)port * (UART1_MAX_PIN_NUMBER + 1u)) + pin;
                CyPins_SetPinDriveMode(portConfigAddr, CY_PINS_DM_STRONG);
                CyPins_SetPin(portConfigAddr);
                UART1_pinDrAdress = portConfigAddr;
            #else
                portConfigAddr = UART1_PORT_CNF_BASE + (UART1_PORT_CNF_SIZE * port) +
                                                                                UART1_PORT_CNF_MODE_OFFSET;
                CY_SYS_PINS_SET_DRIVE_MODE(portConfigAddr, pin, CY_SYS_PINS_DM_STRONG);
                portDataRegAddr = UART1_PORT_CNF_BASE + (UART1_PORT_CNF_SIZE * port) +
                                                                                UART1_PORT_CNF_DR_OFFSET;
                CY_SYS_PINS_SET_PIN(portDataRegAddr, pin);
                UART1_pinDrAdress = portDataRegAddr;
            #endif /* (!CY_PSOC4) */
            UART1_pinNumber = pin;
            UART1_pinPortNumber = port;
        }
    }
#endif /* (UART1_PIN_STATIC_MODE == 1u) */


/*******************************************************************************
* Function Name: UART1_Stop
********************************************************************************
*
* Summary:
*  Empty function. Included for consistency with other components.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void UART1_Stop(void) 
{

}


/*******************************************************************************
* Function Name: UART1_PutString
********************************************************************************
*
* Summary:
*  Sends a NULL terminated string via the Tx pin.
*
* Parameters:
*  string: Pointer to the null terminated string to send
*
* Return:
*  None
*
*******************************************************************************/
void UART1_PutString(const char8 string[]) 
{
    uint8 stringIndex = 1u;
    char8 current = *string;

    /* Until null is reached, print next character */
    while((char8) '\0' != current)
    {
        UART1_PutChar((uint8)current);
        current = string[stringIndex];
        stringIndex++;
    }
}


/*******************************************************************************
* Function Name: UART1_PutArray
********************************************************************************
*
* Summary:
*  Sends byteCount bytes from a memory array via the Tx pin.
*
* Parameters:
*  data: Pointer to the memory array
*  byteCount: Number of bytes to be transmitted
*
* Return:
*  None
*
*******************************************************************************/
void UART1_PutArray(const uint8 array[], uint32 byteCount) 
{
    uint32 arrayIndex;

    for (arrayIndex = 0u; arrayIndex < byteCount; arrayIndex++)
    {
        UART1_PutChar(array[arrayIndex]);
    }
}


/*******************************************************************************
* Function Name: UART1_PutHexByte
********************************************************************************
*
* Summary:
*  Sends a byte in Hex representation (two characters, uppercase for A-F) via
*  the Tx pin.
*
* Parameters:
*  TxHexByte: The byte to be converted to ASCII characters and
*             sent via the Tx pin.
*
* Return:
*  None
*
*******************************************************************************/
void UART1_PutHexByte(uint8 txHexByte) 
{
    static char8 const CYCODE UART1_hex[] = "0123456789ABCDEF";

    UART1_PutChar((uint8) UART1_hex[txHexByte >> UART1_BYTE_UPPER_NIBBLE_SHIFT]);
    UART1_PutChar((uint8) UART1_hex[txHexByte & UART1_BYTE_LOWER_NIBBLE_MASK]);
}


/*******************************************************************************
* Function Name: UART1_PutHexInt
********************************************************************************
*
* Summary:
*  Sends a 16-bit unsigned integer in Hex representation (four characters,
*  uppercase for A-F) via the Tx pin.
*
* Parameters:
*  TxHexInt: The uint16 to be converted to ASCII characters and sent via
*            the Tx pin.
*
* Return:
*  None
*
*******************************************************************************/
void UART1_PutHexInt(uint16 txHexInt) 
{
    UART1_PutHexByte((uint8)(txHexInt >> UART1_U16_UPPER_BYTE_SHIFT));
    UART1_PutHexByte((uint8)(txHexInt & UART1_U16_LOWER_BYTE_MASK));
}


/*******************************************************************************
* Function Name: UART1_PutCRLF
********************************************************************************
*
* Summary:
*  Sends a carriage return (0x0D) and a line feed (0x0A) via the Tx pin.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void UART1_PutCRLF(void) 
{
    UART1_PutChar(0x0Du);
    UART1_PutChar(0x0Au);
}


/* [] END OF FILE */
